
#batch_size
batch_size = 10
#input shape
D_in = 3072
#hidden shape
H = 5
#output shape
D_out = 10

# mean and standard deviation of each channel of input for performing normalization
mean_std_normalization = ([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
# learning rate
LR = 1e-3
# number of epochs for training the model
Epochs = 10
